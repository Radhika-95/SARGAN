# Reproduction notes

1. Install dependencies from `requirements.txt`.
2. Place dataset at `data/dogs-vs-cats-classification/`.
3. Launch Jupyter from repo root; open `notebooks/Applied_AI_midterm.ipynb`.
4. Run setup, split, and model definitions, then train Model A.
5. Pretrain the generator and run 150 full adversarial SRGAN epochs with checkpoints.
6. Train Model B using a frozen final SRGAN generator.
7. Run the held-out evaluation and export figures/metrics.
8. Move `SRGAN_Midterm/figures/*.png` into `images/`, and `SRGAN_Midterm/results/*` into `results/` for publication.

**Caution:** The uploaded notebook is an executed research notebook, not a portable package. Its setup uses the current working directory and its saved CSVs can contain original absolute paths. Adapt these paths on your system before rerunning. Model checkpoints require the corresponding architecture code defined in the notebook.
